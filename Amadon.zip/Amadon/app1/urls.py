from django.urls import path

urlpatterns = [
    path('',views.index)
    path("buy",views.purchase),
    path("pay", views.checkout),
]
