from django.shortcuts import render,redirect
from .models import Order, Product
from django.db.models import Sum

def index(request):
    context = {
        "products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def pay(request):
    last = Order.objects.last()
    price=last.total_price
    full_order = Order.objects.aggregate(Sum('quantity_ordered'))['quantity_ordered__sum']
    full_price = Order.objects.aggregate(Sum('total_price'))['total_price__sum']
    context ={
        'order':full_order,
        'total price':full_price,
        'bill':price,
    }
    return render(request, "store/checkout.html",context)

def buy(request):
    if request.method == 'POST':
        product = Product.objects.filter(id=request.POST["id"])
        if not product:
            return redirect('/')
        else:
            quantity = int(request.POST["quantity"])
            total_charge = quantity*(float(product[0].price))
            Order.objects.create(quantity_ordered=quantity, total_price=total_charge)
            return redirect('/pay')
    else:
        return redirect('/')